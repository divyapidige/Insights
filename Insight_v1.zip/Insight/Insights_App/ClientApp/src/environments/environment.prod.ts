export const environment = {
  production: true,
  apiUrl: 'Http://localhost:81/Home/api',
  virtualDirectoryName:'Home'
};
