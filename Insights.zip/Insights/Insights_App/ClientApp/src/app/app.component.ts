import { Component } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private http: HttpClient) { }

  data;
  title = 'ClientApp';

  ngOnInit() {
    this.loadData();
  }

  async loadData() {
    var header = new HttpHeaders({ 'content-type': 'application/json' });
    var d = await this.http.request('get', 'http://localhost:45364/api/SampleData', { headers: header, reportProgress: false }).toPromise();
    //var d = await this.http.request('get', 'http://192.168.0.102/api/SampleData', { headers: header, reportProgress: false }).toPromise();
    this.data = d;
  }

}
