﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Insights_Core.Interfaces
{
   public interface ISample
    {
        string[] test();
    }
}
